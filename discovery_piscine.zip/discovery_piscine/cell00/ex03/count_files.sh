ls -1 | wc -l
